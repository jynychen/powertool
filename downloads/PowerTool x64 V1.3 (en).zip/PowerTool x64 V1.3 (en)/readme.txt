PowerTool is a free anti-virus&rootkit utility.It offers you the ability to detect, 
analyze and fix various kernel structure modifications and gives you a wide scope of the kernel.
With its help,you can easily spot and remove malwares hidden from normal software.

PowerTool currently supports the following Windows 64-bit versions:
for Vista/Windows 2008 Server/Windows7/Windows 8/Windows 8.1 (64bit)


Contact me :
Email:	ithurricane@gmail.com
QQ:	1371872626
MSN:	ithurricane@hotmail.com
twitter : http://twitter.com/ithurricanept
google+ : ithurricane@gmail.com

If you want to donate to PowerTool Development, please contact me, thanks!

2013-12-02 PowerTool x64 V1.3
  Add:
    1.Add view and remove WFP(Windows Filtering Platform).
    2.Add Support Windows 8/Windows 8.1. 
    3.Add simple self-protect.
  
 Modify:
    1. Enhance kill process 
    2. Modify bug of process's user timer.
    3. Modify bug of view digital signature.
    4. Modify bug of view task scheduler.
    5. As the online scanner site Filterbit invalid, replacing it uploaded to Jotti.


2012-07-29 PowerTool x64 V1.2
  Add:
    1.Add View Filter Driver
    2.Add View NetConnects
    3.Add View Process's Timer
    4.Add Support Windows 8 Release Preview Build 8400 
  
 Modify:
    1. Enhance View Service 
    2. Modify Bug of Detection keyboard spyware